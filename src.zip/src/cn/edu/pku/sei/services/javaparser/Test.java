package cn.edu.pku.sei.services.javaparser;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;

import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTNode;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.Block;
import org.eclipse.jdt.core.dom.CompilationUnit;
import org.eclipse.jdt.core.dom.Statement;

public class Test 
{
	public static char[] inputfile(String filename) // 閿熸枻鎷烽敓鏂ゆ嫹閿熶茎纭锋嫹閿熸枻鎷穋har[]
	{
		FileInputStream fs = null;
		try {
			fs = new FileInputStream(filename);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(fs));
		StringBuffer sb = new StringBuffer();
		String line;  
        try {
			while ((line = reader.readLine()) != null) 
			{  
				sb.append(line + "\n"); 
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	    //System.out.println(javafile);
	    try {
			fs.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return sb.toString().toCharArray();
	}
	
	public static void main(String[] args)
	{
		ASTParser parser = ASTParser.newParser(AST.JLS4); //閿熸枻鎷烽敓鏂ゆ嫹Java閿熸枻鎷烽敓鐨嗚鑼冮敓鑺ユ湰
		parser.setKind(ASTParser.K_STATEMENTS);
				
		Map<String, String> compilerOptions = JavaCore.getOptions();
		compilerOptions.put(JavaCore.COMPILER_COMPLIANCE, JavaCore.VERSION_1_7); //閿熸枻鎷烽敓鏂ゆ嫹Java閿熸枻鎷烽敓鐨嗙増鏈�		compilerOptions.put(JavaCore.COMPILER_CODEGEN_TARGET_PLATFORM, JavaCore.VERSION_1_7);
		compilerOptions.put(JavaCore.COMPILER_SOURCE, JavaCore.VERSION_1_7);
		parser.setCompilerOptions(compilerOptions); //閿熸枻鎷烽敓鐭唻鎷烽敓鏂ゆ嫹閫夐敓鏂ゆ嫹
		
		char[] src = inputfile("hello.java");
		parser.setSource(src);
		
		Block root = (Block)parser.createAST(null);
		List<Statement> statments = root.statements();
		System.out.println(root);
	}
}