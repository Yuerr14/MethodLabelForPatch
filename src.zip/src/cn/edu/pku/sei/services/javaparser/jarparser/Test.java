package cn.edu.pku.sei.services.javaparser.jarparser;

import java.io.FileInputStream;
import java.io.IOException;

import org.objectweb.asm.ClassReader;

public class Test 
{
	public static void main(String args[])
	{
		try {
			FileInputStream fi = new FileInputStream("String.class");
			byte[] b=new byte[fi.available()];
			fi.read(b);
			fi.close();
			ClassReader cr = new ClassReader(b);
			System.out.println(cr.getClassName());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
