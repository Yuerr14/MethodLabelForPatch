package cn.edu.pku.sei.services.javaparser;
import java.io.*;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.*;
import java.util.zip.CRC32;

import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.dom.AST;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;

import cn.edu.pku.sei.services.javaparser.symboltable.MClass;
import cn.edu.pku.sei.services.javaparser.symboltable.MMethod;
import cn.edu.pku.sei.services.javaparser.symboltable.MParameter;
import cn.edu.pku.sei.services.javaparser.symboltable.MVariable;



public class JavaParser 
{
	private ASTParser parser;
	private CompilationUnit cu;
	public BuildSymbolTableVisitor build;
	private String javafile;
	public void release()
	{
		if(cu != null)
			cu.delete();
	}
	public JavaParser()
	{
		parser = ASTParser.newParser(AST.JLS4); //閿熸枻鎷烽敓鏂ゆ嫹Java閿熸枻鎷烽敓鐨嗚鑼冮敓鑺ユ湰
		parser.setKind(ASTParser.K_COMPILATION_UNIT);
				
		Map<String, String> compilerOptions = JavaCore.getOptions();
		compilerOptions.put(JavaCore.COMPILER_COMPLIANCE, JavaCore.VERSION_1_7); //閿熸枻鎷烽敓鏂ゆ嫹Java閿熸枻鎷烽敓鐨嗙増鏈�		compilerOptions.put(JavaCore.COMPILER_CODEGEN_TARGET_PLATFORM, JavaCore.VERSION_1_7);
		compilerOptions.put(JavaCore.COMPILER_SOURCE, JavaCore.VERSION_1_7);
		parser.setCompilerOptions(compilerOptions); //閿熸枻鎷烽敓鐭唻鎷烽敓鏂ゆ嫹閫夐敓鏂ゆ嫹
	}
	public void init(String absolutePath, String projectPath, String commonPath, String jarPath, String MavenPath)
	{
		//parser.createASTs(sourceFilePaths, encodings, bindingKeys, requestor, monitor);
		if(cu != null)
			cu.delete();
		char[] src = inputfile(projectPath + absolutePath);
		parser.setSource(src);
		cu = (CompilationUnit) parser.createAST(null); //閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熺祤ProgessMonitor,閿熸枻鎷烽敓鏂ゆ嫹GUI閿熶茎鏂ゆ嫹閿熸枻鎷烽敓缁烇拷閿熸枻鎷烽敓瑙掕鎷烽敓鏂ゆ嫹瑕侀敓鏂ゆ嫹閿熸枻鎷烽敓绲ll. 閿熸枻鎷烽敓鏂ゆ嫹鍊奸敓鏂ゆ嫹AST閿熶茎闈╂嫹閿熸枻鎷�		BuildSymbolTableVisitor build = new BuildSymbolTableVisitor(); // 閿熸枻鎷烽敓鏂ゆ嫹閿熸枻娉曢敓鏂ゆ嫹
		build = new BuildSymbolTableVisitor();
		cu.accept(build);
		Linker.analysis(absolutePath, projectPath, commonPath, jarPath, MavenPath,build.classes);
	}
	public void init(String absolutePath, String projectPath)
	{
		if(cu != null)
			cu.delete();
		char[] src = inputfile(projectPath + absolutePath);
		cu = AST.parseCompilationUnit(src);//閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熺祤ProgessMonitor,閿熸枻鎷烽敓鏂ゆ嫹GUI閿熶茎鏂ゆ嫹閿熸枻鎷烽敓缁烇拷閿熸枻鎷烽敓瑙掕鎷烽敓鏂ゆ嫹瑕侀敓鏂ゆ嫹閿熸枻鎷烽敓绲ll. 閿熸枻鎷烽敓鏂ゆ嫹鍊奸敓鏂ゆ嫹AST閿熶茎闈╂嫹閿熸枻鎷�		BuildSymbolTableVisitor build = new BuildSymbolTableVisitor(); // 閿熸枻鎷烽敓鏂ゆ嫹閿熸枻娉曢敓鏂ゆ嫹
		build = new BuildSymbolTableVisitor();
		cu.accept(build);
	}
	public String toJson()
	{
		return build.toJSON2();
	}
	
	private char[] inputfile(String filename) // 閿熸枻鎷烽敓鏂ゆ嫹閿熶茎纭锋嫹閿熸枻鎷穋har[]
	{
		FileInputStream fs = null;
		try {
			fs = new FileInputStream(filename);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(fs));
		StringBuffer sb = new StringBuffer();
		String line;  
        try {
			while ((line = reader.readLine()) != null) 
			{  
				sb.append(line + "\n"); 
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
	    javafile = sb.toString();
	    //System.out.println(javafile);
	    try {
			fs.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return javafile.toCharArray();
	}
	public String getType(char[] src, int position,String absolutePath, String projectPath, String commonPath, String jarPath, String MavenPath)
	{
		parser.setSource(src);
		this.javafile = new String(src);
		cu = (CompilationUnit) parser.createAST(null); //閿熸枻鎷烽敓鏂ゆ嫹閿熸枻鎷烽敓鏂ゆ嫹閿熺祤ProgessMonitor,閿熸枻鎷烽敓鏂ゆ嫹GUI閿熶茎鏂ゆ嫹閿熸枻鎷烽敓缁烇拷閿熸枻鎷烽敓瑙掕鎷烽敓鏂ゆ嫹瑕侀敓鏂ゆ嫹閿熸枻鎷烽敓绲ll. 閿熸枻鎷烽敓鏂ゆ嫹鍊奸敓鏂ゆ嫹AST閿熶茎闈╂嫹閿熸枻鎷�		BuildSymbolTableVisitor build = new BuildSymbolTableVisitor(); // 閿熸枻鎷烽敓鏂ゆ嫹閿熸枻娉曢敓鏂ゆ嫹
		build = new BuildSymbolTableVisitor();
		cu.accept(build);
		Linker.analysis(absolutePath, projectPath, commonPath, jarPath, MavenPath, build.classes);
		return getMethod(position);
	}
	public String judge(int line, int length)
	{
		if(length == 0)
			return "no modify";
		List<String> methods = getMethodHashbyline(line, line + length - 1);
		if(methods.size() == 0)
			return "not in a method";
		if(methods.size() == 1)
			return methods.get(0);
		return "in many methods";
	}
	public String getSuperClass()
	{
		for(MClass t_class: build.classes.classes)
		{
			if(t_class.superclass != null && t_class.superclass != "")
				return t_class.superclass;
		}
		return null;
	}
	public List<String> getMethodHashbyline(int line, int last)
	{
		int position = 0;
		int endposition = 0;
		String javaTemp = javafile;
		while(last > 0)
		{
			line--;
			last--;
			if(javaTemp.indexOf("\n") == -1)
				break;
			String aline = javaTemp.substring(0,javaTemp.indexOf("\n"));
			if(line > 0)
				position += aline.length() + 1;
			endposition += aline.length() + 1;
			javaTemp = javaTemp.substring(javaTemp.indexOf("\n") + 1);
		}
		
		List<String> _ret = new ArrayList<String>();
		MMethod method = null;
		for(MClass t_class: build.classes.classes)
		{
			for(MMethod t_method: t_class.methods)
			{
				boolean in = false;
				/*
				if(position <= t_method.startPosition && t_method.endPosition <= endposition)
					in = true;
				if(t_method.startPosition <= endposition && endposition <= t_method.endPosition)
					in = true;
				if(t_method.startPosition <= position && position <= t_method.endPosition)
					in = true;*/
				if(t_method.bodystartPosition < position && endposition < t_method.endPosition)
					in = true;
				if(in)
				{
					method = t_method;
					StringBuffer sHash = new StringBuffer();
					for(String t:method.modifiers)
						sHash.append(t + " ");
					sHash.append(" " + method.return_value + " ");
					sHash.append(" " + method.name + " (");
					for(MParameter t:method.parameters)
					{
						sHash.append(" " + t.type + " ");
						sHash.append(t.name + ",");
					}
					sHash.append(")");
					_ret.add(sHash.toString());
				}
			}
		}
		//String methodbody = javafile.substring(max, min);
		//System.out.println(methodbody);
		
		return _ret;
	}
	public String getMethodHashbyline(int line)
	{
		int max = 0;
		int min = javafile.length();
		int position = 0;
		String javaTemp = javafile;
		while(line > 0)
		{
			line--;
			String aline = javaTemp.substring(0,javaTemp.indexOf("\n"));
			position += aline.length() + 1;
			javaTemp = javaTemp.substring(javaTemp.indexOf("\n") + 1);
		}
		MMethod method = null;
		for(MClass t_class: build.classes.classes)
		{
			for(MMethod t_method: t_class.methods)
			{
				if(position <= t_method.endPosition && position >= t_method.startPosition)
				{
					max = t_method.startPosition;
					min = t_method.endPosition;
					method = t_method;
				}
			}
		}
		if(method == null)
		{
			return null;
		}
		//String methodbody = javafile.substring(max, min);
		//System.out.println(methodbody);
		
		StringBuffer sHash = new StringBuffer();
		for(String t:method.modifiers)
			sHash.append(t + " ");
		sHash.append(" " + method.return_value + " ");
		sHash.append(" " + method.name + " (");
		for(MParameter t:method.parameters)
		{
			sHash.append(" " + t.type + " ");
			sHash.append(t.name + ",");
		}
		sHash.append(")");
		//System.out.println(sHash.toString());
		return sHash.toString();
	}
	public String getMethod(int position)
	{
		int max = 0;
		int min = javafile.length();
		MMethod method = null;
		for(MClass t_class: build.classes.classes)
		{
			for(MMethod t_method: t_class.methods)
			{
				if(t_method.bodystartPosition <= position)
				{
					if(max < t_method.bodystartPosition)
					{
						method = t_method;
						max = t_method.bodystartPosition;
					}
				}
				if(t_method.startPosition >= position)
				{
					if(min > t_method.startPosition)
						min = t_method.startPosition;
				}
			}
		}
		String methodbody = javafile.substring(max, position);
		MethodParser mp = new MethodParser();
		mp.parseMethod(methodbody.toCharArray());
		List<String> list = mp.findPosition();
		//System.out.println(list);
		String type = list.get(0);
		if(type.startsWith("##"))
		{
			type = type.substring(type.indexOf("##") + 2);
			for(String im: this.build.classes.imports)
			{
				if(im.endsWith("." + type))
				{
					type = im;
					break;
				}
			}
		}
		else
		{
			for(MParameter var:method.parameters)
			{
				if(var.name.equals(type))
					type = var.type;
			}
			for(MVariable var:this.build.classes.getClasses().get(0).variables)
			{
				if(var.name.equals(type))
					type = var.type;
			}
		}
		if(list.size() < 3)
			return type;
		return type;
	}
}