import java.io.*;

import cn.edu.pku.sei.services.javaparser.JavaParser;


public class SourceParser 
{
	public static void parseDic(String dicPath)
	{
		File dic = new File(dicPath);
		String[] filenames = dic.list();
		for(String filename:filenames)
		{
			String path = dicPath + "/" + filename;
			File f = new File(path);
			if(f.isDirectory())
			{
				parseDic(path);
			}
			else
			{
				if(!filename.endsWith(".java"))
					continue;
				JavaParser jp = new JavaParser();
				jp.init(path.substring(10), "E:/jresrc/", "E:/jre/", "", "");
				String json = jp.toJson();
				path = path.substring(10, path.indexOf(".java"));
				File ddic = new File("E:/jresrco/" + dicPath.substring(10));
				if(!ddic.exists())
					ddic.mkdirs();
				File output = new File("E:/jresrco/" + path + ".json");
				try {
					FileOutputStream fos = new FileOutputStream(output);
					fos.write(json.getBytes());
					fos.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		}
	}
	public static void main(String args[])
	{
		parseDic("E:/jresrc");
	}
}
