package filter;

public class Node
{
	public String preHash;
	public String Hash;
	public Node(String p, String h)
	{
		preHash = p;
		Hash = h;
	}
}