package filter;

import java.io.*;
import java.util.*;

import cppparser.CppParser;
import cn.edu.pku.sei.services.javaparser.JavaParser;



public class CPPFilter
{
	public static String commitIDsPath = "C:/Users/weiyuhan/git/LibreOffice/orderedDiffCommitIDs.txt";
	public static String patchesPath = "C:/Users/weiyuhan/git/LibreOffice/filteredPatches";
	public static String projectPath = "C:/Users/weiyuhan/git/LibreOffice/core";
	public static String resultPath = "C:/Users/weiyuhan/git/LibreOffice/result";
	public static CppParser cpp = new CppParser();
	public static  String cmd = "cd " + projectPath + "\ngit reset --hard ";
	public String filename;
	public String preHash;
	public String Hash;
	public CPPFilter(String _filename, String _preHash, String _Hash)
	{
		filename = _filename;
		preHash = _preHash;
		Hash = _Hash;
	}

	public void anayHunk(String hunk, DiffInfo diffInf)
	{
		//System.out.println(hunk);
		String numInf = hunk.substring(0, hunk.indexOf(" @@"));
		String[] nums = numInf.split("[^0-9]");
		int pl, pla, l, la;

		pl = Integer.valueOf(nums[0]);
		pla = Integer.valueOf(nums[1]);
		l = Integer.valueOf(nums[3]);
		la = Integer.valueOf(nums[4]);
		
		String[] lines = hunk.split("\n");
		int plus_count = 0;
		int minus_count = 0;
		boolean inEdit = false;
		int temppluscount = 0;
		int tempminuscount = 0;
		int editprefirst = 0;
		int editprelast = 0;
		int editafterfirst = 0;
		int editafterlast = 0;
		for(int i = 1; i < lines.length; i++)
		{
			if(!inEdit)
			{
				editprefirst = pl + i - 1 - plus_count;
				editprelast = pl + i - 1 - plus_count;
				editafterfirst = l + i - 1 - minus_count;
				editafterlast = l + i - 1 - minus_count;
			}
			String line = lines[i];
			if(line.startsWith("+") || line.startsWith("-"))
				inEdit = true;
			else
				inEdit = false;
			if(line.startsWith("+"))
			{
				if(inEdit && temppluscount == 0)
				{
					editafterfirst = l + i - 1 - minus_count;
				}
				plus_count++;
				temppluscount++;
				editafterlast = l + i - 1 - minus_count;
			}
			if(line.startsWith("-"))
			{
				if(inEdit && tempminuscount == 0)
				{
					editprefirst = pl + i - 1 - plus_count;
				}
				minus_count++;
				tempminuscount++;
				editprelast = pl + i - 1 - plus_count;
			}
			if((inEdit == false && ((tempminuscount > 0) || (temppluscount > 0))))
			{
				editprelast = editprelast - editprefirst + 1;
				editafterlast = editafterlast - editafterfirst + 1;
				if(temppluscount == 0)
					editafterlast = 0;
				if(tempminuscount == 0)
					editprelast = 0;
				HunkInfo hunkInf = new HunkInfo(editprefirst, editprelast, 
						editafterfirst, editafterlast);
				diffInf.add(hunkInf);
				tempminuscount = 0;
				temppluscount = 0;
			}
		}
		/*
		for(HunkInfo hunkInf:diffInf.hunks)
		{
			System.out.println("@@ -" + hunkInf.preline + "," + hunkInf.prelast + " +"
					+ hunkInf.line + "," + hunkInf.last + " @@");
		}*/
			
	}
	public  DiffInfo anayDiff(String diff)
	{
		String tdiff = diff;
		String before = tdiff.substring(tdiff.indexOf("--- ") + 6, tdiff.indexOf("+++ ") - 1);
		String after = tdiff.substring(tdiff.indexOf("+++ ") + 6, tdiff.indexOf("\n@@"));
		DiffInfo diffInf = new DiffInfo(before, after);
		String[] hunks = tdiff.split("@@ -");
		for(int i = 1; i < hunks.length; i++)
		{
			try
			{
				anayHunk(hunks[i], diffInf);
			}
			catch(Exception e)
			{
				diffInf.add(new HunkInfo(-1, -1, -1, -1));
			}
			//diffInf.add(hunk);
		}
		return diffInf;
	}
	public  Vector<DiffInfo> anayPatch(File patch)
	{
		Vector<DiffInfo> patchInf = new Vector<DiffInfo>();
		FileInputStream fs = null;
		try {
			fs = new FileInputStream(patch);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(new InputStreamReader(fs));
		StringBuffer sb = new StringBuffer();
		String line;  
        try {
			while ((line = reader.readLine()) != null) 
			{  
				sb.append(line + "\n"); 
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
        String[] diffs = sb.toString().split("diff --git ");
        for(String diff:diffs)
        {
        	if(diff.indexOf("+++ ") == -1)
    			continue;
        	patchInf.add(anayDiff(diff));
        }
        return patchInf;
	}
	public  int exec(String cmd)
	{
		System.out.println("reset to " + cmd + "\n");
		try {
			FileOutputStream fos = new FileOutputStream("reset.bat");
			String w = CPPFilter.cmd + cmd;
			fos.write(w.getBytes());
			fos.close();
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		Runtime runtime=Runtime.getRuntime();
		try{
			Process p = runtime.exec("cmd /c reset.bat");
			
			final InputStream is1 = p.getErrorStream();
	         new Thread(new Runnable() {
	             public void run() {
	                 BufferedReader br = new BufferedReader(new InputStreamReader(is1));
	                 try{
	                 while(br.readLine() != null) ;
	                 }
	                 catch(Exception e) {
	            e.printStackTrace();
	                 }
	             }
	         }).start(); // 鍚姩鍗曠嫭鐨勭嚎绋嬫潵娓呯┖p.getInputStream()鐨勭紦鍐插尯
	         InputStream is2 = p.getInputStream();
	         BufferedReader br2 = new BufferedReader(new InputStreamReader(is2)); 
	         StringBuilder buf = new StringBuilder(); // 淇濆瓨杈撳嚭缁撴灉娴�
	         String line = null;
	         while((line = br2.readLine()) != null) buf.append(line); // 
	         System.out.println("reset to " + cmd + "done!\n");
            if(buf.indexOf("HEAD is now at " + cmd) == -1)
            	return -1;
		}catch(Exception e)
		{
			e.printStackTrace();
			return -1;
		}
		return 0;
	}
	public void run()
	{
		File patch = new File(patchesPath + "/" + filename);
		Vector<DiffInfo> patchInf = null;
		try
		{
		    patchInf = anayPatch(patch);
		    System.out.println("diff num: " + patchInf.size());
		    if(patchInf.size() < 10)
		    {
		    	return;
		    }
		}
		catch(Exception e){}
		try
		{
			File file= new File(resultPath + "/" + filename+ ".out");
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(filename.getBytes());
			fos.write("\n".getBytes());
			try
			{
			    patchInf = anayPatch(patch);
			    System.out.println("diff num: " + patchInf.size());
			    if(patchInf.size() >= 100)
			    {
			    	fos.write("too many diff".getBytes());
			    	fos.write("\n".getBytes());
			    	fos.close();
			    	return;
			    }
			}
			catch(Exception e)
			{
				e.printStackTrace();
				fos.write("exception occur!\n".getBytes());
				fos.close();
				return;
				//System.exit(0);
			}
			System.out.println("patch anaylz done!");
			int hi = 0;
			int status = exec(preHash);
			if(status == -1)
			{
				fos.write("can't reset\n".getBytes());
				fos.close();
				return;
			}
			Vector<String> preresult = new Vector<String>();
			for(DiffInfo diff:patchInf)
			{
				if(diff.prefilename.endsWith(".h") || diff.prefilename.endsWith(".c")
						|| diff.prefilename.endsWith(".cpp") || diff.prefilename.endsWith(".cxx"))
				{
					System.out.println("jp make!");
					try
					{
						cpp.init(projectPath + "/" + diff.prefilename);
					}catch(Exception e)
					{
						e.printStackTrace();
						for(HunkInfo hunk:diff.hunks)
							preresult.add("diff exception occur!");
						//preresult.add("exception occur!");
						continue;
					}
				}
				for(HunkInfo hunk:diff.hunks)
				{
					if(hunk.line == -1)
					{
						preresult.add("hunk exception occur!");
						continue;
					}
					System.out.println(hi);
					hi++;
					if(!(diff.prefilename.endsWith(".h") || diff.prefilename.endsWith(".c")
							|| diff.prefilename.endsWith(".cpp") || diff.prefilename.endsWith(".cxx")))
					{
						preresult.add("no a java file");
						continue;
					}
					String j = cpp.judge(hunk.preline, hunk.prelast);
					preresult.add(j);
				}
				
			}
			
			
			status = exec(Hash);
			if(status == -1)
			{
				fos.write("can't reset\n".getBytes());
				fos.close();
				return;
			}
			Vector<String> result = new Vector<String>();
			for(DiffInfo diff:patchInf)
			{
				if(diff.filename.endsWith(".h") || diff.filename.endsWith(".c")
						|| diff.filename.endsWith(".cpp") || diff.filename.endsWith(".cxx"))
				{
					try
					{
						cpp.init(projectPath + "/" + diff.filename);
					}catch(Exception e)
					{
						e.printStackTrace();
						//e.printStackTrace();
						for(HunkInfo hunk:diff.hunks)
							result.add("diff exception occur!");
						//preresult.add("exception occur!");
						continue;
					}
				}
				for(HunkInfo hunk:diff.hunks)
				{
					if(hunk.line == -1)
					{
						result.add("hunk exception occur!");
						continue;
					}
					System.out.println(hi);
					hi++;
					if(!(diff.filename.endsWith(".h") || diff.filename.endsWith(".c")
							|| diff.filename.endsWith(".cpp")|| diff.filename.endsWith(".cxx")))
					{
						result.add("no a java file");
						continue;
					}
					String j = cpp.judge(hunk.line, hunk.last);
					result.add(j);
				}
				
			}
			
				
			int i = 0;
			for(DiffInfo diff:patchInf)
			{
				fos.write("diff --git ".getBytes());
				if(!diff.filename.equals("ev/null"))
					fos.write(diff.filename.getBytes());
				else if(!diff.prefilename.equals("ev/null"))
					fos.write(diff.prefilename.getBytes());
				else
					fos.write("dev/null".getBytes());
				fos.write("\n".getBytes());
				int p = i;
				for(; i < p + diff.hunks.size(); i++)
				{
					fos.write("@@ ".getBytes());
					if(result.get(i).equals("no modify"))
					{
						fos.write(preresult.get(i).getBytes());
						fos.write("\n".getBytes());
					}
					else if(preresult.get(i).equals("no modify"))
					{
						fos.write(result.get(i).getBytes());
						fos.write("\n".getBytes());
					}
					else if(result.get(i).equals("in many methods") || 
							preresult.get(i).equals("in many methods"))
					{
						fos.write("in many methods\n".getBytes());
					}
					else if(result.get(i).equals("not in a method") || 
							preresult.get(i).equals("not in a method"))
					{
						fos.write("not in a method\n".getBytes());
					}
					else if(result.get(i).equals("diff exception occur!") || 
							preresult.get(i).equals("diff exception occur!"))
					{
						fos.write("diff exception occur!\n".getBytes());
					}
					else if(result.get(i).equals("hunk exception occur!") || 
							preresult.get(i).equals("hunk exception occur!"))
					{
						fos.write("hunk exception occur!\n".getBytes());
					}
					else if(result.get(i).equals(preresult.get(i)))
					{
						fos.write(result.get(i).getBytes());
						fos.write("\n".getBytes());
					}
					else if(result.get(i).equals("no a java file"))
					{
						fos.write(preresult.get(i).getBytes());
						fos.write("\n".getBytes());
					}
					else if(preresult.get(i).equals("no a java file"))
					{
						fos.write(result.get(i).getBytes());
						fos.write("\n".getBytes());
					}
					else
					{
						fos.write("not in the same method\n".getBytes());
					}
				}
			}
			fos.write("\n\n".getBytes());
			fos.close();
			//	cpp.release();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	public static void main(String[] args)
	{
		//Filter m = new Filter(args[0], args[1], args[2]);
		CPPFilter m = new CPPFilter("100162_1.txt", "e6c002b", "d0bcc7f");
		m.run();
		System.out.println("success");
	}
}
