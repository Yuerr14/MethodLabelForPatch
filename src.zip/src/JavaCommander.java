import java.io.*;
import java.util.Properties;

import filter.*;


public class JavaCommander 
{
	public static String commitIDsPath = "C:/Users/weiyuhan/git/LibreOffice/orderedDiffCommitIDs.txt";
	public static String patchesPath = "C:/Users/weiyuhan/git/LibreOffice/filteredPatches";
	public static void main(String[] args)
	{
		CommitIDs ids = new CommitIDs(commitIDsPath);
		File patches = new File(patchesPath);
		String[] files = patches.list();
		for(int i = 0; i < files.length; i++)
		{
			String filename = files[i];
			System.out.println(i + " : " + filename);
			String[] commitInfo = filename.split("_");
			int bugid = Integer.parseInt(commitInfo[0]);
			int index = Integer.parseInt(commitInfo[1].substring(0,commitInfo[1].indexOf(".")));
			Node n = ids.map.get(bugid).get(index-1);

			Filter filter = new Filter(filename, n.preHash, n.Hash);
			filter.run();
		}
	}
}
