package cppparser.symboltable;

import java.util.Vector;

public class MTable 
{
	public Vector<MMethod> methods;
	public MTable()
	{
		methods = new Vector<MMethod>();
	}
}
